Aetheris CENTRAL Recovery Auth E2E FIX3 v1.2.4

Purpose:
- Repair the specific condition where DB recovery hash is correct but /api/scanner-agent/heartbeat still returns 401.
- Locate the actual FastAPI heartbeat endpoint/dependency tree at runtime.
- Patch authentication expressions individually, even when another marker already exists in the same file.
- Generate a fresh separate recovery credential.
- Restart ONLY the same API container.
- Perform a REAL HTTP heartbeat using that fresh recovery credential.
- Write a laptop credential file only after HTTP 2xx succeeds.

Non-destructive:
No compose down, rm, prune, volume deletion, scanner recreation, OpenVAS task deletion, or DB reset.
On failure, exact host/container source and the prior recovery hash/hint are restored.
