#!/usr/bin/env python3
from __future__ import annotations
import argparse, ast, hashlib, json, re, sys
from pathlib import Path

AUTH_MARKER = "AETHERIS_V124_E2E_AUTH_FIX3"
HELPER_MARKER = "AETHERIS_V124_E2E_PY_TOKEN_MATCH_FIX3"

RAW_COLON = re.compile(r"(?P<qual>\b(?:[A-Za-z_][A-Za-z0-9_]*\.)?)agent_token_hash\s*=\s*:(?P<p>[A-Za-z_][A-Za-z0-9_]*)", re.I)
RAW_PSYCOPG = re.compile(r"(?P<qual>\b(?:[A-Za-z_][A-Za-z0-9_]*\.)?)agent_token_hash\s*=\s*%\((?P<p>[A-Za-z_][A-Za-z0-9_]*)\)s", re.I)
DICT_EQ = re.compile(r"(?P<obj>[a-z_][A-Za-z0-9_]*)\s*\[\s*['\"]agent_token_hash['\"]\s*\]\s*==\s*(?P<h>[A-Za-z_][A-Za-z0-9_]*)")
GET_EQ = re.compile(r"(?P<obj>[a-z_][A-Za-z0-9_]*)\.get\(\s*['\"]agent_token_hash['\"]\s*\)\s*==\s*(?P<h>[A-Za-z_][A-Za-z0-9_]*)")
ATTR_EQ = re.compile(r"(?P<obj>[a-z_][A-Za-z0-9_]*)\.agent_token_hash\s*==\s*(?P<h>[A-Za-z_][A-Za-z0-9_]*)")
CD_GET = re.compile(r"(?:hmac|secrets)\.compare_digest\(\s*(?P<obj>[a-z_][A-Za-z0-9_]*)\.get\(\s*['\"]agent_token_hash['\"]\s*\)\s*,\s*(?P<h>[A-Za-z_][A-Za-z0-9_]*)\s*\)")
CD_DICT = re.compile(r"(?:hmac|secrets)\.compare_digest\(\s*(?P<obj>[a-z_][A-Za-z0-9_]*)\s*\[\s*['\"]agent_token_hash['\"]\s*\]\s*,\s*(?P<h>[A-Za-z_][A-Za-z0-9_]*)\s*\)")
CD_ATTR = re.compile(r"(?:hmac|secrets)\.compare_digest\(\s*(?P<obj>[a-z_][A-Za-z0-9_]*)\.agent_token_hash\s*,\s*(?P<h>[A-Za-z_][A-Za-z0-9_]*)\s*\)")

HELPER = r'''

# AETHERIS_V124_E2E_PY_TOKEN_MATCH_FIX3
# Durable edge-agent token match used only for Python-side row/mapping comparisons.
def _aetheris_v124_e2e_token_match(scanner, token_hash):
    import datetime as _dt
    import hmac as _hmac

    def _get(key):
        try:
            if hasattr(scanner, "get"):
                return scanner.get(key)
        except Exception:
            pass
        try:
            return scanner[key]
        except Exception:
            return getattr(scanner, key, None)

    def _eq(value):
        return bool(value) and _hmac.compare_digest(str(value), str(token_hash))

    if _eq(_get("agent_token_hash")) or _eq(_get("agent_recovery_token_hash")):
        return True
    if not _eq(_get("agent_previous_token_hash")):
        return False
    expires = _get("agent_previous_token_valid_until")
    if not expires:
        return False
    if isinstance(expires, str):
        try:
            expires = _dt.datetime.fromisoformat(expires.replace("Z", "+00:00"))
        except Exception:
            return False
    if getattr(expires, "tzinfo", None) is None:
        expires = expires.replace(tzinfo=_dt.timezone.utc)
    return expires > _dt.datetime.now(_dt.timezone.utc)
'''

def sha(p: Path):
    return hashlib.sha256(p.read_bytes()).hexdigest()

def already_wrapped(text: str, start: int, end: int) -> bool:
    # Inspect forward from this exact equality only. Looking behind can see a
    # different auth query earlier in the same file and incorrectly suppress
    # this match (the defect FIX3 is designed to eliminate).
    w = text[end:min(len(text), end+420)]
    return "agent_recovery_token_hash" in w and ("agent_previous_token_hash" in w or AUTH_MARKER in w)

def patch_raw(text: str):
    total = 0
    for rx, style in ((RAW_COLON, "colon"), (RAW_PSYCOPG, "psycopg")):
        out=[]; pos=0; n=0
        for m in rx.finditer(text):
            if already_wrapped(text, m.start(), m.end()):
                continue
            # avoid SET assignment
            before=text[max(0,m.start()-900):m.start()].lower()
            if before.rfind("set") > before.rfind("where") and before.rfind("set") > before.rfind("update") >= 0:
                continue
            q=m.group("qual") or ""; p=m.group("p")
            if style == "colon":
                ph=f":{p}"
            else:
                ph=f"%({p})s"
            repl=(f"({q}agent_token_hash = {ph} OR {q}agent_recovery_token_hash = {ph} "
                  f"OR ({q}agent_previous_token_hash = {ph} AND {q}agent_previous_token_valid_until > NOW())) "
                  f"/* {AUTH_MARKER} */")
            out.append(text[pos:m.start()]); out.append(repl); pos=m.end(); n+=1
        if n:
            out.append(text[pos:]); text="".join(out); total+=n
    return text,total

def patch_python(text: str):
    total=0
    for rx in (CD_GET, CD_DICT, CD_ATTR, GET_EQ, DICT_EQ, ATTR_EQ):
        text,n=rx.subn(lambda m: f"_aetheris_v124_e2e_token_match({m.group('obj')}, {m.group('h')})", text)
        total += n
    if total and HELPER_MARKER not in text:
        try:
            tree=ast.parse(text)
            insert=0
            for node in tree.body:
                if isinstance(node,(ast.Import,ast.ImportFrom)) or (isinstance(node,ast.Expr) and isinstance(getattr(node,'value',None),ast.Constant) and isinstance(node.value.value,str)):
                    insert=max(insert,int(getattr(node,'end_lineno',node.lineno)))
                else:
                    break
            lines=text.splitlines(True); lines.insert(insert,HELPER+"\n"); text="".join(lines)
        except Exception:
            text=HELPER+"\n"+text
    return text,total

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--root',required=True)
    ap.add_argument('--stage',required=True)
    ap.add_argument('--focus-json',required=True)
    a=ap.parse_args()
    root=Path(a.root).resolve(); app=root/'backend'/'app'; stage=Path(a.stage).resolve()
    focus_doc=json.loads(Path(a.focus_json).read_text(encoding='utf-8'))
    focus=set()
    for route in focus_doc.get('routes',[]):
        for info in [route.get('endpoint')] + list(route.get('dependencies') or []):
            if not info or not info.get('file'): continue
            f=str(info['file']).replace('\\','/')
            idx=f.rfind('/app/')
            if idx>=0:
                rel='backend/app/'+f[idx+5:]
                focus.add(rel)
    candidates=[]
    for p in app.rglob('*.py'):
        if '__pycache__' in p.parts: continue
        try: t=p.read_text(encoding='utf-8')
        except UnicodeDecodeError: t=p.read_text(encoding='utf-8-sig')
        rel=str(p.relative_to(root)).replace('\\','/')
        if 'agent_token_hash' in t or rel in focus:
            candidates.append((p,rel,t))
    report={'focus_files':sorted(focus),'files':[],'raw_patches':0,'python_patches':0}
    for src,rel,text in candidates:
        orig=text
        text,nraw=patch_raw(text)
        text,npy=patch_python(text)
        try: ast.parse(text,filename=str(src))
        except SyntaxError as e:
            print(f'ERROR syntax after patch {rel}: {e}',file=sys.stderr); return 10
        dst=stage/rel; dst.parent.mkdir(parents=True,exist_ok=True); dst.write_text(text,encoding='utf-8',newline='')
        report['raw_patches']+=nraw; report['python_patches']+=npy
        report['files'].append({'relative_path':rel,'changed':text!=orig,'focus':rel in focus,'source_sha256':hashlib.sha256(orig.encode()).hexdigest(),'staged_sha256':sha(dst),'marker_present':AUTH_MARKER in text or HELPER_MARKER in text})
    if not report['files']:
        print('ERROR no route/auth candidate files found',file=sys.stderr); return 11
    (stage/'patch-report.json').write_text(json.dumps(report,indent=2),encoding='utf-8')
    print(json.dumps(report,indent=2))
    return 0
if __name__=='__main__': raise SystemExit(main())
