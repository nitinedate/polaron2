#!/usr/bin/env python3
import importlib, inspect, json, os, sys

def find_app():
    for name in ("app.main", "app.api", "main"):
        try:
            m = importlib.import_module(name)
        except Exception:
            continue
        app = getattr(m, "app", None)
        if app is not None and hasattr(app, "routes"):
            return app, name
    # fall back: imported app package may expose app
    try:
        import app as pkg
        a = getattr(pkg, "app", None)
        if a is not None and hasattr(a, "routes"):
            return a, "app"
    except Exception:
        pass
    raise RuntimeError("FastAPI app object could not be located")

def callable_info(fn):
    if fn is None:
        return None
    try:
        f = inspect.getsourcefile(fn) or inspect.getfile(fn)
    except Exception:
        f = None
    return {
        "name": getattr(fn, "__name__", type(fn).__name__),
        "qualname": getattr(fn, "__qualname__", getattr(fn, "__name__", type(fn).__name__)),
        "module": getattr(fn, "__module__", None),
        "file": os.path.abspath(f) if f else None,
    }

def walk_dep(d, out, seen):
    fn = getattr(d, "call", None)
    if fn is not None:
        key = id(fn)
        if key not in seen:
            seen.add(key)
            info = callable_info(fn)
            if info:
                out.append(info)
    for child in getattr(d, "dependencies", []) or []:
        walk_dep(child, out, seen)

app, app_module = find_app()
selected = []
for r in getattr(app, "routes", []):
    path = str(getattr(r, "path", ""))
    methods = sorted(getattr(r, "methods", []) or [])
    if path.endswith("/scanner-agent/heartbeat") or path == "/api/scanner-agent/heartbeat":
        deps = []
        dep = getattr(r, "dependant", None)
        if dep is not None:
            walk_dep(dep, deps, set())
        selected.append({
            "path": path,
            "methods": methods,
            "endpoint": callable_info(getattr(r, "endpoint", None)),
            "dependencies": deps,
        })
print(json.dumps({"app_module": app_module, "routes": selected}, indent=2))
if not selected:
    sys.exit(4)
