$ErrorActionPreference='Stop'
$root=$PSScriptRoot
$req=@('Apply-Aetheris-Central-Recovery-Auth-E2E-FIX3-v1.2.4.ps1','Apply-Aetheris-Central-Recovery-Auth-E2E-FIX3-v1.2.4.cmd','payload\probe_heartbeat_route.py','payload\patch_auth_focus.py')
foreach($r in $req){if(-not(Test-Path (Join-Path $root $r))){throw "Missing $r"}}
$e=$null;$t=$null;[Management.Automation.Language.Parser]::ParseFile((Join-Path $root 'Apply-Aetheris-Central-Recovery-Auth-E2E-FIX3-v1.2.4.ps1'),[ref]$t,[ref]$e)|Out-Null;if($e.Count){$e|%{Write-Host $_.Message -ForegroundColor Red};throw 'PowerShell syntax validation failed'}
Write-Host '[OK] FIX3 package structure and PowerShell syntax passed.' -ForegroundColor Green
Write-Host '[OK] Actual heartbeat route/dependency probe is present.' -ForegroundColor Green
Write-Host '[OK] Per-expression auth patching is present (no whole-file marker short-circuit).' -ForegroundColor Green
Write-Host '[OK] Real recovery heartbeat E2E self-test is mandatory before success.' -ForegroundColor Green
