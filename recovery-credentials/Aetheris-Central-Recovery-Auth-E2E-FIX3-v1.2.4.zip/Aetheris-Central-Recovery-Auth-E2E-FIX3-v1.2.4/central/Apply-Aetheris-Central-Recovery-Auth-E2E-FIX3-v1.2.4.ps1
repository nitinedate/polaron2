[CmdletBinding()]
param(
  [Parameter(Position=0)][string]$Root='F:\rag_new2',
  [Parameter(Position=1)][string]$Scanner='external',
  [string]$ComposeFile='docker-compose.https.yml',
  [string]$TenantSlug='aetheris'
)
$ErrorActionPreference='Stop'; Set-StrictMode -Version 2.0
function B([string]$s){Write-Host '';Write-Host ('='*78) -ForegroundColor DarkGray;Write-Host $s -ForegroundColor Cyan;Write-Host ('='*78) -ForegroundColor DarkGray}
function OK([string]$s){Write-Host "[OK] $s" -ForegroundColor Green}; function I([string]$s){Write-Host "[INFO] $s" -ForegroundColor Cyan}; function W([string]$s){Write-Host "[WARN] $s" -ForegroundColor Yellow}
function DockerExe(){ $c=Get-Command docker.exe -CommandType Application -ErrorAction SilentlyContinue|Select-Object -First 1; if(-not $c){$c=Get-Command docker -CommandType Application -ErrorAction SilentlyContinue|Select-Object -First 1}; if(-not $c){throw 'docker.exe not found'}; return $c.Source }
$docker=DockerExe
function D([string[]]$a,[switch]$Allow){$old=$ErrorActionPreference;try{$ErrorActionPreference='Continue';$r=& $docker @a 2>&1;$ec=$LASTEXITCODE}finally{$ErrorActionPreference=$old};$t=(@($r|%{$_.ToString()}) -join [Environment]::NewLine); if($ec -ne 0 -and -not $Allow){throw "docker failed ($ec): $($a -join ' ')`n$t"};[pscustomobject]@{ExitCode=[int]$ec;Text=$t;Lines=@($r|%{$_.ToString()})}}
function First($r){foreach($x in @($r.Lines)){if($x -and $x.Trim()){return $x.Trim()}};''}
function ShaText([string]$v){$s=[Security.Cryptography.SHA256]::Create();try{(($s.ComputeHash([Text.Encoding]::UTF8.GetBytes($v))|%{$_.ToString('x2')}) -join '')}finally{$s.Dispose()}}
function NewTok(){ $b=New-Object byte[] 32;$r=[Security.Cryptography.RandomNumberGenerator]::Create();try{$r.GetBytes($b)}finally{$r.Dispose()};[Convert]::ToBase64String($b).TrimEnd('=').Replace('+','-').Replace('/','_') }
function Sql([string]$v){"'"+$v.Replace("'","''")+"'"}
$Root=(Resolve-Path -LiteralPath $Root).Path;$compose=Join-Path $Root $ComposeFile
if(-not(Test-Path $compose)){throw "compose not found: $compose"}
$stamp=Get-Date -Format yyyyMMdd-HHmmss;$snap=Join-Path $Root "recovery-snapshots\central-recovery-auth-e2e-fix3-$stamp";$stage=Join-Path $env:TEMP ("aetheris-auth-fix3-"+[guid]::NewGuid().ToString('N'));New-Item -ItemType Directory -Force -Path $snap,$stage|Out-Null
$probe=Join-Path $PSScriptRoot 'payload\probe_heartbeat_route.py';$patcher=Join-Path $PSScriptRoot 'payload\patch_auth_focus.py'
$sourceTouched=$false;$runtimeTouched=$false;$oldHash=$null;$oldHint=$null;$api=$null;$pg=$null;$appRoot=$null;$backups=@()
try{
 B 'Aetheris v1.2.4 CENTRAL Recovery Auth E2E FIX3';Write-Host "Root: $Root";Write-Host "Scanner: $Scanner";Write-Host 'No historical backup is used as source. No scanner/job/OpenVAS/container/volume recreation.'
 B '1. PREFLIGHT + LOCATE ACTUAL HEARTBEAT ROUTE';$di=D @('info') -Allow;if($di.ExitCode -ne 0){throw "Docker unavailable`n$($di.Text)"};$api=First(D @('compose','-f',$compose,'ps','-q','api') -Allow);$pg=First(D @('compose','-f',$compose,'ps','-q','postgres') -Allow);if(-not $api -or -not $pg){throw 'existing api/postgres container not running'};OK "API=$api";OK "Postgres=$pg"
 $ar=D @('exec',$api,'python','-c','import app,os; print(os.path.abspath(next(iter(app.__path__))))');$appRoot=First $ar;if(-not $appRoot){throw 'could not resolve app root'};I "API app root: $appRoot"
 D @('cp',$probe,"${api}:/tmp/aetheris_probe_route.py")|Out-Null;$pr=D @('exec',$api,'python','/tmp/aetheris_probe_route.py') -Allow;$pr.Text|Set-Content -Encoding UTF8 (Join-Path $snap 'heartbeat-route.json');if($pr.ExitCode -ne 0){throw "heartbeat route probe failed`n$($pr.Text)"};OK 'Actual heartbeat endpoint/dependency tree captured.'
 B '2. STAGE PER-EXPRESSION AUTH PATCH FROM LIVE SOURCE';$py=(Get-Command python.exe -ErrorAction SilentlyContinue|Select-Object -First 1);$pref=@();if(-not $py){$py=(Get-Command py.exe -ErrorAction SilentlyContinue|Select-Object -First 1);$pref=@('-3')};if(-not $py){throw 'Python 3 not found on central Windows host'};$routeJson=Join-Path $snap 'heartbeat-route.json';$args=@($pref)+@($patcher,'--root',$Root,'--stage',$stage,'--focus-json',$routeJson);$rr=& $py.Source @args 2>&1;$rc=$LASTEXITCODE;$rr|Set-Content -Encoding UTF8 (Join-Path $snap 'patcher-output.txt');if($rc -ne 0){throw "auth patch staging failed; live source unchanged`n$($rr -join [Environment]::NewLine)"};$report=Get-Content -Raw (Join-Path $stage 'patch-report.json')|ConvertFrom-Json;Copy-Item (Join-Path $stage 'patch-report.json') (Join-Path $snap 'patch-report.json');Write-Host "Raw SQL auth patches: $($report.raw_patches)";Write-Host "Python auth patches: $($report.python_patches)";$items=@($report.files|?{$_.changed -eq $true -or $_.marker_present -eq $true});if($items.Count -eq 0){throw 'no auth runtime candidate files selected'};OK 'Staged Python syntax passed.'
 B '3. SNAPSHOT + COMMIT EXACT CANDIDATE FILES';foreach($it in $items){$rel=[string]$it.relative_path;$win=$rel-replace '/','\';$live=Join-Path $Root $win;if(-not(Test-Path $live)){continue};$bak=Join-Path $snap ("host-original\"+$win);New-Item -ItemType Directory -Force -Path (Split-Path $bak)|Out-Null;Copy-Item $live $bak -Force;$sub=$rel.Substring('backend/app/'.Length);$cp=$appRoot.TrimEnd('/')+'/'+$sub;$cb=Join-Path $snap ("container-original\"+$win);New-Item -ItemType Directory -Force -Path (Split-Path $cb)|Out-Null;D @('cp',"${api}:$cp",$cb)|Out-Null;$backups+=,[pscustomobject]@{Rel=$rel;Live=$live;HostBak=$bak;Container=$cp;ContainerBak=$cb};$st=Join-Path $stage $win;if(Test-Path $st){Copy-Item $st $live -Force;D @('cp',$live,"${api}:$cp")|Out-Null;$sourceTouched=$true;$runtimeTouched=$true}}
 $compile=@($backups|%{$_.Container}|Select-Object -Unique);if($compile.Count){$cr=D (@('exec',$api,'python','-m','py_compile')+$compile) -Allow;if($cr.ExitCode -ne 0){throw "runtime compile failed`n$($cr.Text)"}};OK 'Host + same API container synchronized and compiled.'
 B '4. RESYNC SEPARATE RECOVERY CREDENTIAL IN DATABASE';$where="lower(COALESCE(connection_mode,''))='edge_agent'";if($Scanner -match '^[0-9a-fA-F-]{36}$'){$where+=" AND id=$(Sql $Scanner)::uuid"}else{$where+=" AND lower(name)=lower($(Sql $Scanner))"};$q="SELECT id::text,COALESCE(name,''),COALESCE(agent_recovery_token_hash,''),COALESCE(agent_recovery_token_hint,'') FROM firm_aetheris.vuln_scanners WHERE $where ORDER BY last_heartbeat_at DESC NULLS LAST LIMIT 1;";$row=First(D @('exec',$pg,'psql','-U','forensic','-d','forensic','-At','-F','|','-c',$q));if(-not $row){throw "scanner not found: $Scanner"};$p=$row.Split('|');$sid=$p[0];$sname=$p[1];$oldHash=$p[2];$oldHint=$p[3];$tok=NewTok;$hash=ShaText $tok;$hint=$tok.Substring(0,8);$u="UPDATE firm_aetheris.vuln_scanners SET agent_recovery_token_hash=$(Sql $hash),agent_recovery_token_hint=$(Sql $hint),agent_recovery_updated_at=NOW() WHERE id=$(Sql $sid)::uuid;";D @('exec',$pg,'psql','-U','forensic','-d','forensic','-v','ON_ERROR_STOP=1','-c',$u)|Out-Null;OK "Recovery hash synchronized for $sname ($sid).";I ("Fingerprint: "+$hash.Substring(0,16)+'...')
 B '5. RESTART SAME API + REAL RECOVERY HEARTBEAT SELF-TEST';D @('restart',$api)|Out-Null;for($n=1;$n -le 30;$n++){Start-Sleep -Seconds 2;$h=D @('exec',$api,'python','-c',"import urllib.request; print(urllib.request.urlopen('http://127.0.0.1:8080/health',timeout=3).status)") -Allow;if($h.ExitCode -eq 0){break};if($n -eq 30){throw 'API did not recover after restart'}}
 $tmp=Join-Path $env:TEMP ('aetheris-recovery-e2e-'+[guid]::NewGuid().ToString('N')+'.txt');[IO.File]::WriteAllText($tmp,$tok,(New-Object Text.UTF8Encoding($false)));D @('cp',$tmp,"${api}:/tmp/aetheris-recovery-e2e-token")|Out-Null;Remove-Item $tmp -Force; $code=@'
import json, urllib.request, urllib.error
p='/tmp/aetheris-recovery-e2e-token'
t=open(p,encoding='utf-8').read().strip()
req=urllib.request.Request('http://127.0.0.1:8080/api/scanner-agent/heartbeat', data=json.dumps({'version':'central-e2e-fix3-v1.2.4'}).encode(), headers={'Authorization':'Bearer '+t,'X-Tenant':'aetheris','Content-Type':'application/json'}, method='POST')
try:
    r=urllib.request.urlopen(req,timeout=10); print('HTTP_STATUS='+str(r.status)); print(r.read().decode()[:1000])
except urllib.error.HTTPError as e:
    print('HTTP_STATUS='+str(e.code)); print(e.read().decode()[:1000]); raise SystemExit(20 if e.code==401 else 21)
finally:
    import os
    try: os.remove(p)
    except OSError: pass
'@;$test=D @('exec',$api,'python','-c',$code) -Allow;$test.Text|Set-Content -Encoding UTF8 (Join-Path $snap 'recovery-heartbeat-selftest.txt');Write-Host $test.Text;if($test.ExitCode -ne 0){throw "REAL recovery heartbeat self-test failed. Central runtime still rejected the freshly DB-matched credential. See $snap"};OK 'REAL recovery heartbeat accepted freshly generated recovery credential.'
 B '6. WRITE ONLY THE VERIFIED MATCHED LAPTOP CREDENTIAL';$dir=Join-Path $Root 'recovery-credentials';New-Item -ItemType Directory -Force -Path $dir|Out-Null;$file=Join-Path $dir ("Aetheris-Agent-Recovery-Credentials-E2E-VERIFIED-$stamp.txt");$lines=@('Aetheris v1.2.4 E2E verified recovery credential',"scanner_id=$sid","scanner_name=$sname","tenant_slug=$TenantSlug","recovery_token_hint=$hint","recovery_token_sha256=$hash","AGENT_RECOVERY_TOKEN=$tok");[IO.File]::WriteAllLines($file,[string[]]$lines,(New-Object Text.UTF8Encoding($false)));OK "VERIFIED credential: $file"
 B 'CENTRAL E2E FIX3 COMPLETE';Write-Host 'Use ONLY the E2E-VERIFIED credential file on LAPTOP LIVE-FIX3.' -ForegroundColor Yellow;Write-Host "Snapshot: $snap"
}catch{
 W 'Failure detected; restoring exact pre-run source/runtime and recovery hash where possible.'
 foreach($b in @($backups)){try{if(Test-Path $b.HostBak){Copy-Item $b.HostBak $b.Live -Force};if($api -and (Test-Path $b.ContainerBak)){D @('cp',$b.ContainerBak,"${api}:$($b.Container)") -Allow|Out-Null}}catch{}}
 if($pg -and $oldHash -ne $null){try{$rh=if($oldHash){Sql $oldHash}else{'NULL'};$ri=if($oldHint){Sql $oldHint}else{'NULL'};$r="UPDATE firm_aetheris.vuln_scanners SET agent_recovery_token_hash=$rh,agent_recovery_token_hint=$ri,agent_recovery_updated_at=NOW() WHERE lower(name)=lower($(Sql $Scanner)) AND lower(COALESCE(connection_mode,''))='edge_agent';";D @('exec',$pg,'psql','-U','forensic','-d','forensic','-c',$r) -Allow|Out-Null}catch{}}
 if($api -and $runtimeTouched){try{D @('restart',$api) -Allow|Out-Null}catch{}}
 Write-Host '';Write-Host ('='*78) -ForegroundColor Red;Write-Host 'CENTRAL RECOVERY AUTH E2E FIX3 FAILED' -ForegroundColor Red;Write-Host ('='*78) -ForegroundColor Red;Write-Host $_.Exception.Message -ForegroundColor Red;Write-Host "Diagnostics: $snap";exit 1
}finally{try{D @('exec',$api,'rm','-f','/tmp/aetheris_probe_route.py','/tmp/aetheris-recovery-e2e-token') -Allow|Out-Null}catch{};Remove-Item $stage -Recurse -Force -ErrorAction SilentlyContinue}
