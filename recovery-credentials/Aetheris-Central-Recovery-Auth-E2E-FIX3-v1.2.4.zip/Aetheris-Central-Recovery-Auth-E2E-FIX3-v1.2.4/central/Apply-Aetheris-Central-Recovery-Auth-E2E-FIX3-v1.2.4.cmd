@echo off
setlocal EnableExtensions
set "ROOT=%~1"
if not defined ROOT set "ROOT=F:\rag_new2"
set "SCANNER=%~2"
if not defined SCANNER set "SCANNER=external"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Apply-Aetheris-Central-Recovery-Auth-E2E-FIX3-v1.2.4.ps1" -Root "%ROOT%" -Scanner "%SCANNER%"
exit /b %ERRORLEVEL%
